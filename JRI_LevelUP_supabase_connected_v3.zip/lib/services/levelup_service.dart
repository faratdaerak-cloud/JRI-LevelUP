import 'package:supabase_flutter/supabase_flutter.dart';

class LevelUpService {
  LevelUpService._();
  static final LevelUpService instance = LevelUpService._();

  SupabaseClient get _db => Supabase.instance.client;
  String get _uid {
    final id = _db.auth.currentUser?.id;
    if (id == null) throw AuthException('Сессия завершена. Войди снова.');
    return id;
  }

  Future<Map<String, dynamic>> getProfile() async {
    final row = await _db.from('profiles').select().eq('id', _uid).maybeSingle();
    return row ?? <String, dynamic>{};
  }

  Future<List<Map<String, dynamic>>> getTasks() async {
    final rows = await _db.from('tasks').select().eq('user_id', _uid).order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createTask(String title, {String? description}) async {
    await _db.from('tasks').insert({
      'user_id': _uid, 'title': title.trim(),
      if (description != null && description.trim().isNotEmpty) 'description': description.trim(),
    });
  }

  Future<void> completeTask(String id, bool completed) async {
    await _db.from('tasks').update({
      'status': completed ? 'completed' : 'todo',
      'completed_at': completed ? DateTime.now().toUtc().toIso8601String() : null,
    }).eq('id', id).eq('user_id', _uid);
  }

  Future<List<Map<String, dynamic>>> getGoals() async {
    final rows = await _db.from('goals').select().eq('user_id', _uid).order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createGoal(String title, {String? description, String? category}) async {
    await _db.from('goals').insert({
      'user_id': _uid, 'title': title.trim(),
      if (description != null && description.trim().isNotEmpty) 'description': description.trim(),
      if (category != null && category.trim().isNotEmpty) 'category': category.trim(),
    });
  }

  Future<List<Map<String, dynamic>>> getDiaryEntries() async {
    final rows = await _db.from('diary_entries').select().eq('user_id', _uid).order('entry_date', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> createDiaryEntry(String body, int mood, {String? title}) async {
    final today = DateTime.now().toIso8601String().split('T').first;
    await _db.from('diary_entries').insert({
      'user_id': _uid, 'body': body.trim(), 'mood': mood, 'entry_date': today,
      if (title != null && title.trim().isNotEmpty) 'title': title.trim(),
    });
  }

  Future<List<Map<String, dynamic>>> getXpEvents() async {
    final rows = await _db.from('xp_events').select().eq('user_id', _uid).order('created_at', ascending: false).limit(30);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> signOut() => _db.auth.signOut();
}
