import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'theme.dart';
import 'screens/app_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  const url = String.fromEnvironment('SUPABASE_URL');
  const publishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

  if (url.isNotEmpty && publishableKey.isNotEmpty) {
    await Supabase.initialize(url: url, publishableKey: publishableKey);
  }

  runApp(const JriLevelUpApp(
    isConfigured: url.isNotEmpty && publishableKey.isNotEmpty,
  ));
}

class JriLevelUpApp extends StatelessWidget {
  final bool isConfigured;
  const JriLevelUpApp({super.key, required this.isConfigured});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'JRI LevelUP',
    debugShowCheckedModeBanner: false,
    theme: buildLevelUpTheme(),
    home: isConfigured ? const AppGate() : const ConfigurationScreen(),
  );
}

class ConfigurationScreen extends StatelessWidget {
  const ConfigurationScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(
    body: Center(
      child: Padding(
        padding: EdgeInsets.all(28),
        child: Text(
          'JRI LevelUP\\n\\nДля подключения укажи SUPABASE_URL и SUPABASE_PUBLISHABLE_KEY через --dart-define. Инструкция находится в README.md.',
          textAlign: TextAlign.center,
        ),
      ),
    ),
  );
}
