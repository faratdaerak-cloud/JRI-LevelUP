import 'package:flutter/material.dart';
import '../services/levelup_service.dart';
import '../theme.dart';
import 'widgets.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});
  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}
class _ProgressScreenState extends State<ProgressScreen> {
  late Future<List<Map<String, dynamic>>> _events;
  late Future<Map<String, dynamic>> _profile;
  @override
  void initState() { super.initState(); _reload(); }
  void _reload() { _events = LevelUpService.instance.getXpEvents(); _profile = LevelUpService.instance.getProfile(); }
  @override
  Widget build(BuildContext context) => ScreenFrame(
    eyebrow: 'Твой рост в цифрах', title: 'Прогресс', subtitle: 'Показатели загружаются из твоего профиля.',
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      FutureBuilder<Map<String, dynamic>>(future: _profile, builder: (context, snap) {
        final p = snap.data ?? {};
        return Row(children: [
          Expanded(child: _metric((p['xp'] ?? 0).toString(), 'Всего XP', Icons.bolt_rounded)),
          const SizedBox(width: 10), Expanded(child: _metric((p['level'] ?? 1).toString(), 'Уровень', Icons.trending_up_rounded)),
        ]);
      }),
      const SizedBox(height: 22), const Text('История опыта', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      FutureBuilder<List<Map<String, dynamic>>>(future: _events, builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const LoadingBlock();
        if (snap.hasError) return ErrorBlock(error: snap.error!, retry: () => setState(_reload));
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const Panel(child: Text('Пока нет начислений XP. Они появятся после подключения защищённого механизма наград.', style: TextStyle(color: LevelUpColors.muted)));
        return Column(children: rows.map((e) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Panel(padding: const EdgeInsets.all(14), child: Row(children: [
          const AccentIcon(Icons.bolt_rounded, color: LevelUpColors.blue), const SizedBox(width: 12),
          Expanded(child: Text(e['reason']?.toString() ?? 'Событие', style: const TextStyle(fontWeight: FontWeight.w600))),
          Text('+${e['amount'] ?? 0} XP', style: const TextStyle(color: LevelUpColors.success, fontWeight: FontWeight.w800)),
        ])))).toList());
      }),
    ]),
  );
  Widget _metric(String value, String label, IconData icon) => Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    AccentIcon(icon), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), Text(label, style: const TextStyle(color: LevelUpColors.muted, fontSize: 11)),
  ]));
}
