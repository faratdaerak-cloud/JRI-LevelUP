import 'package:flutter/material.dart';
import '../theme.dart';
import 'widgets.dart';

class AiScreen extends StatefulWidget {
  const AiScreen({super.key});
  @override
  State<AiScreen> createState() => _AiScreenState();
}
class _AiScreenState extends State<AiScreen> {
  final _controller = TextEditingController();
  String? _answer;
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => ScreenFrame(
    eyebrow: 'Персональный помощник', title: 'AI LevelUP',
    subtitle: 'Идеи, планирование и поддержка на твоём пути.',
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [AccentIcon(Icons.auto_awesome_rounded, color: LevelUpColors.blue), SizedBox(width: 12), Text('Твой AI-напарник', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16))]),
        const SizedBox(height: 14), const Text('С чего начнём?', style: TextStyle(color: LevelUpColors.muted)),
        const SizedBox(height: 10), Wrap(spacing: 8, runSpacing: 8, children: ['План на день', 'Сохрани мотивацию', 'Разбей большую цель', 'Итоги недели'].map((s) => ActionChip(label: Text(s), onPressed: () => _controller.text = s)).toList()),
      ])),
      const SizedBox(height: 14),
      if (_answer != null) Panel(child: Text(_answer!, style: const TextStyle(height: 1.5))),
      const SizedBox(height: 12),
      TextField(controller: _controller, minLines: 2, maxLines: 4, decoration: InputDecoration(hintText: 'Напиши, что хочешь улучшить…', suffixIcon: IconButton(icon: const Icon(Icons.arrow_upward_rounded), onPressed: () => setState(() { _answer = 'AI-интерфейс готов, но серверная AI-модель ещё не подключена. Твой запрос сохранён только в этом демонстрационном экране.'; _controller.clear(); })))),
      const SizedBox(height: 10), const Text('Реальная AI-модель и история диалогов — следующий этап интеграции.', style: TextStyle(color: LevelUpColors.muted, fontSize: 11)),
    ]),
  );
}
