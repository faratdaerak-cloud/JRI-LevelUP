import 'package:flutter/material.dart';
import '../services/levelup_service.dart';
import '../theme.dart';
import 'widgets.dart';

class GoalsScreen extends StatefulWidget {
  const GoalsScreen({super.key});
  @override
  State<GoalsScreen> createState() => _GoalsScreenState();
}
class _GoalsScreenState extends State<GoalsScreen> {
  late Future<List<Map<String, dynamic>>> _goals;
  @override
  void initState() { super.initState(); _reload(); }
  void _reload() { _goals = LevelUpService.instance.getGoals(); }
  Future<void> _add() async {
    final title = await askText(context, 'Новая цель');
    if (title == null) return;
    final desc = await askText(context, 'Описание цели', hint: 'К чему хочешь прийти?');
    try { await LevelUpService.instance.createGoal(title, description: desc); setState(_reload); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: $e'))); }
  }
  @override
  Widget build(BuildContext context) => ScreenFrame(
    eyebrow: 'Твоё направление', title: 'Цели', subtitle: 'Твои цели хранятся в личном пространстве Supabase.',
    child: Column(children: [
      Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Добавить цель'))),
      FutureBuilder<List<Map<String, dynamic>>>(future: _goals, builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const LoadingBlock();
        if (snap.hasError) return ErrorBlock(error: snap.error!, retry: () => setState(_reload));
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const Panel(child: Text('Целей пока нет. Создай первую — она появится здесь.', style: TextStyle(color: LevelUpColors.muted)));
        return Column(children: rows.map((g) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Panel(child: Row(children: [
          const AccentIcon(Icons.flag_outlined), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(g['title']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
            if ((g['description'] ?? '').toString().isNotEmpty) Text(g['description'].toString(), style: const TextStyle(color: LevelUpColors.muted, fontSize: 12)),
            const SizedBox(height: 5), Text('Статус: ${g['status'] ?? 'active'}', style: const TextStyle(color: LevelUpColors.blue, fontSize: 10)),
          ])),
        ])))).toList());
      }),
    ]),
  );
}
