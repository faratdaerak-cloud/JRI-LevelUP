import 'package:flutter/material.dart';
import '../services/levelup_service.dart';
import '../theme.dart';
import 'widgets.dart';

class DiaryScreen extends StatefulWidget {
  const DiaryScreen({super.key});
  @override
  State<DiaryScreen> createState() => _DiaryScreenState();
}
class _DiaryScreenState extends State<DiaryScreen> {
  late Future<List<Map<String, dynamic>>> _entries;
  final _body = TextEditingController();
  int _mood = 4;
  bool _saving = false;
  @override
  void initState() { super.initState(); _reload(); }
  @override
  void dispose() { _body.dispose(); super.dispose(); }
  void _reload() { _entries = LevelUpService.instance.getDiaryEntries(); }
  Future<void> _save() async {
    if (_body.text.trim().isEmpty) return;
    setState(() => _saving = true);
    try {
      await LevelUpService.instance.createDiaryEntry(_body.text, _mood);
      _body.clear(); setState(_reload);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Запись сохранена')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сохранить: $e')));
    } finally { if (mounted) setState(() => _saving = false); }
  }
  @override
  Widget build(BuildContext context) => ScreenFrame(
    eyebrow: 'Личный журнал', title: 'Дневник', subtitle: 'Твои записи доступны только твоему аккаунту.',
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Как прошёл твой день?', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12), const Text('Настроение', style: TextStyle(color: LevelUpColors.muted, fontSize: 12)),
        const SizedBox(height: 7),
        Wrap(spacing: 4, children: List.generate(5, (i) => ChoiceChip(label: Text(['Тяжело','Так себе','Нормально','Хорошо','Классно'][i]), selected: _mood == i, onSelected: (_) => setState(() => _mood = i), selectedColor: LevelUpColors.purple.withOpacity(.25)))),
        const SizedBox(height: 12),
        TextField(controller: _body, minLines: 3, maxLines: 5, decoration: const InputDecoration(hintText: 'Что сегодня получилось? Что хочется улучшить?')),
        const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.bookmark_add_outlined), label: Text(_saving ? 'Сохраняю…' : 'Сохранить запись'))),
      ])),
      const SizedBox(height: 22), const Text('Предыдущие записи', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      FutureBuilder<List<Map<String, dynamic>>>(future: _entries, builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const LoadingBlock();
        if (snap.hasError) return ErrorBlock(error: snap.error!, retry: () => setState(_reload));
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const Panel(child: Text('Здесь появятся твои сохранённые записи.', style: TextStyle(color: LevelUpColors.muted)));
        return Column(children: rows.map((e) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(e['entry_date']?.toString() ?? '', style: const TextStyle(color: LevelUpColors.blue, fontWeight: FontWeight.w700, fontSize: 11)),
          const SizedBox(height: 7), Text(e['body']?.toString() ?? '', style: const TextStyle(height: 1.5)),
        ])))).toList());
      }),
    ]),
  );
}
