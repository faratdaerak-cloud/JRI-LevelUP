import 'package:flutter/material.dart';
import '../services/levelup_service.dart';
import '../theme.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Map<String, dynamic>>> _tasks;
  late Future<Map<String, dynamic>> _profile;
  @override
  void initState() { super.initState(); _reload(); }
  void _reload() { _tasks = LevelUpService.instance.getTasks(); _profile = LevelUpService.instance.getProfile(); }
  Future<void> _addTask() async {
    final title = await askText(context, 'Новая задача');
    if (title == null) return;
    try { await LevelUpService.instance.createTask(title); setState(_reload); }
    catch (e) { _message('Не удалось создать задачу: $e'); }
  }
  Future<void> _toggle(Map<String, dynamic> task, bool done) async {
    try { await LevelUpService.instance.completeTask(task['id'].toString(), done); setState(_reload); }
    catch (e) { _message('Не удалось обновить задачу: $e'); }
  }
  void _message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => ScreenFrame(
    eyebrow: 'JRI LevelUP', title: 'Твой день.\\nТвой следующий уровень.',
    subtitle: 'Маленькие действия создают большой прогресс.',
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      FutureBuilder<Map<String, dynamic>>(future: _profile, builder: (context, snap) {
        final p = snap.data ?? {};
        final xp = (p['xp'] as num?)?.toInt() ?? 0;
        final level = (p['level'] as num?)?.toInt() ?? 1;
        return Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Text('ТВОЙ УРОВЕНЬ', style: TextStyle(color: LevelUpColors.muted, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.2)), const Spacer(), Text('LEVEL ${level.toString().padLeft(2, '0')}', style: const TextStyle(color: LevelUpColors.purple, fontWeight: FontWeight.w800))]),
          const SizedBox(height: 12), Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(xp.toString(), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
            const Padding(padding: EdgeInsets.only(left: 7, bottom: 6), child: Text('XP', style: TextStyle(color: LevelUpColors.blue, fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 8), const Text('Опыт из профиля Supabase', style: TextStyle(color: LevelUpColors.muted, fontSize: 11)),
        ]));
      }),
      const SizedBox(height: 20),
      Row(children: [const Expanded(child: Text('Задачи на сегодня', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))), IconButton(onPressed: _addTask, icon: const Icon(Icons.add_circle_outline, color: LevelUpColors.purple))]),
      FutureBuilder<List<Map<String, dynamic>>>(future: _tasks, builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const LoadingBlock();
        if (snap.hasError) return ErrorBlock(error: snap.error!, retry: () => setState(_reload));
        final tasks = snap.data ?? [];
        if (tasks.isEmpty) return Panel(child: const Text('Пока нет задач. Нажми +, чтобы добавить первую.', style: TextStyle(color: LevelUpColors.muted)));
        return Column(children: tasks.map((t) {
          final done = t['status'] == 'completed';
          return Padding(padding: const EdgeInsets.only(bottom: 9), child: Panel(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12), child: Row(children: [
            AccentIcon(Icons.task_alt_rounded, color: done ? LevelUpColors.success : LevelUpColors.purple),
            const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t['title']?.toString() ?? 'Задача', style: TextStyle(fontWeight: FontWeight.w700, decoration: done ? TextDecoration.lineThrough : null)),
              if ((t['description'] ?? '').toString().isNotEmpty) Text(t['description'].toString(), style: const TextStyle(color: LevelUpColors.muted, fontSize: 11)),
            ])),
            Checkbox(value: done, onChanged: (v) => _toggle(t, v ?? false), activeColor: LevelUpColors.success),
          ])));
        }).toList());
      }),
    ]),
  );
}
