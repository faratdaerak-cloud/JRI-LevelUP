import 'package:flutter/material.dart';
import '../theme.dart';
import 'home_screen.dart';
import 'ai_screen.dart';
import 'goals_screen.dart';
import 'progress_screen.dart';
import 'diary_screen.dart';
import 'profile_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  static const _pages = [HomeScreen(), AiScreen(), GoalsScreen(), ProgressScreen(), DiaryScreen(), ProfileScreen()];
  static const _destinations = [
    NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Главная'),
    NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'AI'),
    NavigationDestination(icon: Icon(Icons.flag_outlined), label: 'Цели'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Прогресс'),
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Дневник'),
    NavigationDestination(icon: Icon(Icons.person_outline_rounded), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: _index, children: _pages),
    bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (v) => setState(() => _index = v), destinations: _destinations, height: 72, labelBehavior: NavigationDestinationLabelBehavior.alwaysShow),
    floatingActionButton: _index == 0 ? FloatingActionButton(onPressed: () => setState(() => _index = 1), backgroundColor: LevelUpColors.purple, foregroundColor: Colors.white, child: const Icon(Icons.auto_awesome_rounded)) : null,
  );
}
