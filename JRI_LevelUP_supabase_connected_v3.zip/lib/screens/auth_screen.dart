import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false;
  bool _busy = false;
  String? _error;
  String? _notice;

  @override
  void dispose() { _email.dispose(); _password.dispose(); super.dispose(); }

  Future<void> _submit() async {
    setState(() { _busy = true; _error = null; _notice = null; });
    try {
      final auth = Supabase.instance.client.auth;
      if (_register) {
        final response = await auth.signUp(email: _email.text.trim(), password: _password.text);
        if (response.session == null && mounted) {
          setState(() => _notice = 'Аккаунт создан. Проверь почту, если подтверждение email включено в Supabase.');
        }
      } else {
        await auth.signInWithPassword(email: _email.text.trim(), password: _password.text);
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (e) {
      if (mounted) setState(() => _error = 'Не удалось выполнить запрос. Проверь подключение и настройки Supabase.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.auto_awesome_rounded, size: 44, color: LevelUpColors.purple),
          const SizedBox(height: 16),
          const Text('JRI LevelUP', textAlign: TextAlign.center, style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(_register ? 'Создай аккаунт и начни свой путь.' : 'Войди, чтобы продолжить свой путь.', textAlign: TextAlign.center, style: const TextStyle(color: LevelUpColors.muted)),
          const SizedBox(height: 30),
          TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.mail_outline_rounded))),
          const SizedBox(height: 12),
          TextField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'Пароль', prefixIcon: Icon(Icons.lock_outline_rounded))),
          if (_error != null) ...[const SizedBox(height: 12), Text(_error!, style: const TextStyle(color: LevelUpColors.danger))],
          if (_notice != null) ...[const SizedBox(height: 12), Text(_notice!, style: const TextStyle(color: LevelUpColors.success))],
          const SizedBox(height: 18),
          FilledButton(onPressed: _busy ? null : _submit, child: Padding(padding: const EdgeInsets.all(13), child: Text(_busy ? 'Подожди…' : (_register ? 'Создать аккаунт' : 'Войти')))),
          TextButton(onPressed: _busy ? null : () => setState(() { _register = !_register; _error = null; _notice = null; }), child: Text(_register ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Зарегистрироваться')),
        ],
      )),
    ))),
  );
}
