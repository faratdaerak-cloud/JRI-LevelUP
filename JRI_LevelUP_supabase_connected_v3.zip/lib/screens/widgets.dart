import 'package:flutter/material.dart';
import '../theme.dart';

class ScreenFrame extends StatelessWidget {
  final String eyebrow, title;
  final String? subtitle;
  final Widget child;
  const ScreenFrame({super.key, required this.eyebrow, required this.title, this.subtitle, required this.child});
  @override
  Widget build(BuildContext context) => SafeArea(child: ListView(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
    children: [
      Text(eyebrow.toUpperCase(), style: const TextStyle(color: LevelUpColors.purple, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.8)),
      const SizedBox(height: 8), Text(title, style: Theme.of(context).textTheme.headlineLarge),
      if (subtitle != null) ...[const SizedBox(height: 6), Text(subtitle!, style: Theme.of(context).textTheme.bodyMedium)],
      const SizedBox(height: 22), child,
    ],
  ));
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(17)});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: padding, child: child));
}

class AccentIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  const AccentIcon(this.icon, {super.key, this.color = LevelUpColors.purple});
  @override
  Widget build(BuildContext context) => Container(
    width: 42, height: 42,
    decoration: BoxDecoration(color: color.withOpacity(.13), borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(.22))),
    child: Icon(icon, color: color, size: 21),
  );
}

class LoadingBlock extends StatelessWidget {
  const LoadingBlock({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
}

class ErrorBlock extends StatelessWidget {
  final Object error;
  final VoidCallback retry;
  const ErrorBlock({super.key, required this.error, required this.retry});
  @override
  Widget build(BuildContext context) => Panel(child: Column(children: [
    const Icon(Icons.cloud_off_outlined, color: LevelUpColors.muted, size: 28),
    const SizedBox(height: 8),
    Text('Не удалось загрузить данные\\n$error', textAlign: TextAlign.center, style: const TextStyle(color: LevelUpColors.muted, fontSize: 12)),
    const SizedBox(height: 10), OutlinedButton(onPressed: retry, child: const Text('Повторить')),
  ]));
}

Future<String?> askText(BuildContext context, String title, {String hint = 'Название'}) async {
  final controller = TextEditingController();
  final result = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
    title: Text(title),
    content: TextField(controller: controller, autofocus: true, decoration: InputDecoration(hintText: hint)),
    actions: [
      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
      FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Сохранить')),
    ],
  ));
  controller.dispose();
  if (result == null || result.trim().isEmpty) return null;
  return result.trim();
}
