import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/levelup_service.dart';
import '../theme.dart';
import 'widgets.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}
class _ProfileScreenState extends State<ProfileScreen> {
  late Future<Map<String, dynamic>> _profile;
  @override
  void initState() { super.initState(); _profile = LevelUpService.instance.getProfile(); }
  @override
  Widget build(BuildContext context) => ScreenFrame(
    eyebrow: 'Аккаунт', title: 'Профиль', subtitle: 'Данные профиля из Supabase.',
    child: Column(children: [
      FutureBuilder<Map<String, dynamic>>(future: _profile, builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const LoadingBlock();
        if (snap.hasError) return ErrorBlock(error: snap.error!, retry: () => setState(() => _profile = LevelUpService.instance.getProfile()));
        final p = snap.data ?? {};
        final name = (p['display_name'] ?? p['username'] ?? 'Пользователь').toString();
        return Panel(child: Column(children: [
          Container(width: 76, height: 76, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [LevelUpColors.purple, LevelUpColors.blue])), child: const Icon(Icons.person_outline_rounded, color: Colors.white, size: 38)),
          const SizedBox(height: 12), Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4), Text(Supabase.instance.client.auth.currentUser?.email ?? '', style: const TextStyle(color: LevelUpColors.muted, fontSize: 11)),
          const SizedBox(height: 14), Text('Уровень ${p['level'] ?? 1} · ${p['xp'] ?? 0} XP', style: const TextStyle(color: LevelUpColors.blue, fontWeight: FontWeight.w700)),
          const SizedBox(height: 5), Text('Тариф: ${p['premium_status'] ?? 'free'}', style: const TextStyle(color: LevelUpColors.muted, fontSize: 11)),
        ]));
      }),
      const SizedBox(height: 14),
      Panel(child: Row(children: [const AccentIcon(Icons.shield_outlined, color: LevelUpColors.blue), const SizedBox(width: 12), const Expanded(child: Text('Данные защищены правилами доступа Supabase (RLS).', style: TextStyle(fontSize: 12, color: LevelUpColors.muted)))])),
      const SizedBox(height: 14),
      SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () async { await LevelUpService.instance.signOut(); }, icon: const Icon(Icons.logout_rounded), label: const Text('Выйти из аккаунта'), style: OutlinedButton.styleFrom(foregroundColor: LevelUpColors.text))),
    ]),
  );
}
