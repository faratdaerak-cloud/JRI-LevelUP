import 'package:flutter/material.dart';

class LevelUpColors {
  static const background = Color(0xFF090A10);
  static const surface = Color(0xFF12141E);
  static const surfaceRaised = Color(0xFF191C29);
  static const border = Color(0xFF282B3A);
  static const purple = Color(0xFF8B5CFF);
  static const purpleDeep = Color(0xFF5A2CCB);
  static const blue = Color(0xFF35A7FF);
  static const text = Color(0xFFF4F2FA);
  static const muted = Color(0xFF9A9CAF);
  static const success = Color(0xFF55D6A2);
  static const danger = Color(0xFFFF6B7A);
}

ThemeData buildLevelUpTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: LevelUpColors.purple, brightness: Brightness.dark, surface: LevelUpColors.surface);
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme.copyWith(primary: LevelUpColors.purple, secondary: LevelUpColors.blue, surface: LevelUpColors.surface),
    scaffoldBackgroundColor: LevelUpColors.background,
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontSize: 29, fontWeight: FontWeight.w800, letterSpacing: -0.7, color: LevelUpColors.text),
      titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: LevelUpColors.text),
      titleMedium: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: LevelUpColors.text),
      bodyLarge: TextStyle(fontSize: 15, height: 1.45, color: LevelUpColors.text),
      bodyMedium: TextStyle(fontSize: 13, height: 1.4, color: LevelUpColors.muted),
    ),
    cardTheme: CardThemeData(
      color: LevelUpColors.surface, elevation: 0, margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: LevelUpColors.border)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: const Color(0xFF10121A), indicatorColor: LevelUpColors.purple.withOpacity(.20),
      labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(color: s.contains(WidgetState.selected) ? LevelUpColors.text : LevelUpColors.muted, fontSize: 10, fontWeight: FontWeight.w700)),
      iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(color: s.contains(WidgetState.selected) ? LevelUpColors.purple : LevelUpColors.muted, size: 21)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: LevelUpColors.surfaceRaised, hintStyle: const TextStyle(color: LevelUpColors.muted),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: LevelUpColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: LevelUpColors.border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: LevelUpColors.purple, width: 1.4)),
    ),
  );
}
