# JRI LevelUP — Supabase-connected Flutter starter

## What is connected
- Supabase Auth: email/password sign-up, sign-in, sign-out.
- `profiles`: current user's profile and XP/level display.
- `tasks`: list, create, mark complete.
- `goals`: list and create.
- `diary_entries`: list and save entries.
- `xp_events`: read-only activity history (client cannot award XP).

All user-owned reads and writes rely on the existing Supabase RLS policies. The app does not ship a service-role/secret key.

## Run locally

```bash
flutter pub get
flutter run \
  --dart-define=SUPABASE_URL=https://ycyxwfcyhtbovdmizgrw.supabase.co \
  --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

Use the **publishable key** from Supabase Project Settings → API Keys. Do not use a secret/service-role key in a mobile app.

If either compile-time value is missing, the app shows a configuration screen instead of silently using demo data.

## Database assumptions
The app uses the existing `public` tables and columns:
- `profiles(id, display_name, xp, level, premium_status)`
- `tasks(id, user_id, title, description, due_at, priority, status, xp_reward, completed_at, created_at)`
- `goals(id, user_id, title, description, category, status, target_date, created_at)`
- `diary_entries(id, user_id, title, body, mood, entry_date, is_private, created_at)`
- `xp_events(id, user_id, task_id, amount, reason, created_at)`

Existing RLS policies restrict data to `auth.uid()`. `xp_events` is select-only for the client. Task completion updates the task status but intentionally does **not** increase XP; XP should be granted by a trusted server-side function after validating the completion.

## Not yet implemented
AI model / Edge Function, secure XP-award function, photo storage, GPS/maps, Spotify OAuth, Premium billing, push notifications, production deep links, and full Android/iOS build validation.

This is a connected development starter, not a published or compiled APK/IPA.
